namespace Actio.Common.Events
{
    //Marker interface
    public interface IEvent
    {
    }
}